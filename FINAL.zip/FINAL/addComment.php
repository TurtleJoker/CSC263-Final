<?php
    include('connection.php');
    $commentDate = $_POST['date'];
    $comment = $_POST['comments'];
    $handlerID = $_POST['handlerID'];
    $commentID = $_POST['commentID'];
    $ipAdr = $_POST['ipAddress'];

    $sql1="INSERT INTO incidents_comments(commentID, handlerID, comments, date, ipAddress)
          VALUES ('$commentID', '$handlerID', '$comment', '$commentDate', '$ipAdr')";
    if ($conn->query($sql1) === TRUE) {
          echo "Record updated successfully";
        } else {
          echo "Error updating record: " . $conn->error;
        }
    
    $conn->close();
?>