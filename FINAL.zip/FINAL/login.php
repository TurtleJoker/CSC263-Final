<!DOCTYPE html>
<html>

  <head>
    <title>Logging in...</title>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body>
    <header>
      <h1>
        CSIRT
      </h1>
      <h4>
        Computer Security Incident Response Teams
      </h4>
    </header>
    <?php
include('connection.php');
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM login WHERE (username = '$username') AND (password ='$password') limit 1";

$result = $conn->query($sql);

$row = mysqli_fetch_assoc($result);

if($row == 0) {
    $url = "login.html";

    echo "<script>alert('Error. You should enter the valid username or password.')</script>";

    echo "<meta http-equiv='Refresh' content='0; URL = $url'>";
} else {
    echo '<h2 style="font-size:24pt;color:black;text-align:center">'."Logging in...".'</h2>';

    $url = "index.html";

    echo "<meta http-equiv='Refresh' content='2;URL=$url'>";
}

$conn->close();
?>
    <h2>Powered by Runtime Errors</h2>
  </body>

</html>